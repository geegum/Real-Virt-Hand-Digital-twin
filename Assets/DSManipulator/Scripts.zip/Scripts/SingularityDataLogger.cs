using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;

public class SingularityDataLogger : MonoBehaviour
{
    private string filePath;
    private float elapsedTime; // ������ �ð�

    void Start()
    {
        filePath = Application.dataPath + "SingularityData.csv";
        elapsedTime = 0f; // �ʱ�ȭ

        if (!File.Exists(filePath))
        {
            File.WriteAllText(filePath, "ElapsedTime,JointAngles,Jacobian\n");
        }
    }

    void Update()
    {
        elapsedTime += Time.deltaTime; // �� ������ ��� �ð� ����
    }

    public void LogData(float[] jointAngles, Matrix<double> jacobian)
    {
        string elapsedTimeString = elapsedTime.ToString("F3"); // ������ �ð��� ���ڿ��� ��ȯ, �Ҽ��� 3�ڸ�����
        string jointAngleString = string.Join(",", jointAngles);
        string jacobianString = MatrixToString(jacobian);

        string logEntry = $"{elapsedTimeString},{jointAngleString},{jacobianString}\n";
        File.AppendAllText(filePath, logEntry);
    }

    private string MatrixToString(Matrix<double> matrix)
    {
        List<string> elements = new List<string>();

        for (int i = 0; i < matrix.RowCount; i++)
        {
            for (int j = 0; j < matrix.ColumnCount; j++)
            {
                elements.Add(matrix[i, j].ToString());
            }
        }

        return string.Join(",", elements);
    }
}
