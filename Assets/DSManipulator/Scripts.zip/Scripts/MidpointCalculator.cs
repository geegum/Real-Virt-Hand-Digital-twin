using UnityEngine;

public class MidpointCalculator : MonoBehaviour
{
    public Transform transformA;
    public Transform transformB;
    public Transform resultTransform;
    public Transform rotationReferenceTransform; // ȸ���� ������ Transform

    void Update()
    {
        if (transformA != null && transformB != null && resultTransform != null && rotationReferenceTransform != null)
        {
            // �� ��ǥ�� ���� ��� (�۷ι� ��ǥ��)
            Vector3 midpoint = (transformA.position + transformB.position) / 2.0f;
            resultTransform.position = midpoint - new Vector3(0f,0.03f,0f);

            // rotationReferenceTransform�� ȸ���� resultTransform�� �Ҵ�
            //resultTransform.rotation = rotationReferenceTransform.rotation;
        }
    }
}
