using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public class Socket_SVD : MonoBehaviour
{
    private TcpClient client;
    private NetworkStream stream;
    public static Socket_SVD Instance { get; private set; }
    public float[] newAngles = new float[6];
    public float[] jacobianMatrix = new float[36]; // 6x6 ���ں�� ���
    public float rotationAngle; // �߰��� rotationAngle ����
    private string clientId = "unity"; // ������ Ŭ���̾�Ʈ �ĺ��� ����
    private bool isConnected = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
            DontDestroyOnLoad(this.gameObject);
        }

        ConnectToServer();
    }

    private async void ConnectToServer()
    {
        try
        {
            client = new TcpClient();
            await client.ConnectAsync("127.0.0.1", 5000); // ���� IP �ּҿ� ��Ʈ ��ȣ
            stream = client.GetStream();
            await SendClientId();
            Debug.Log("Connected to server.");
            isConnected = true;
            StartSendingData(); // ������ ����Ǹ� �ֱ������� ������ ���� ����
        }
        catch (Exception e)
        {
            Debug.LogError($"Could not connect to server: " + e.Message);
        }
    }

    private async Task SendClientId()
    {
        try
        {
            if (stream != null)
            {
                byte[] idData = Encoding.UTF8.GetBytes(clientId);
                await stream.WriteAsync(idData, 0, idData.Length);
                Debug.Log("Client ID sent to server.");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"Error sending client ID: " + e.Message);
        }
    }


    private async void StartSendingData()
    {
        while (isConnected)
        {
            SendData(newAngles, jacobianMatrix, rotationAngle);
            await Task.Delay(10); // 10ms ��� (100Hz �ֱ�)
        }
    }

    public async void SendData(float[] angles, float[] jacobian, float rotationAngle)
    {
        if (!isConnected || client == null || !client.Connected)
        {
            Debug.LogError($"Not connected to server.");
            return;
        }

        try
        {
            if (stream != null)
            {
                // ������ ũ��� (���� �迭 + ���ں�� ��� + rotationAngle) * float ũ��
                byte[] data = new byte[(angles.Length + jacobian.Length + 1) * sizeof(float)];
                Buffer.BlockCopy(angles, 0, data, 0, angles.Length * sizeof(float));
                Buffer.BlockCopy(jacobian, 0, data, angles.Length * sizeof(float), jacobian.Length * sizeof(float));
                Buffer.BlockCopy(BitConverter.GetBytes(rotationAngle), 0, data, (angles.Length + jacobian.Length) * sizeof(float), sizeof(float));

                // ������ ��Ŷ ũ�⸦ �α׷� ���
                Debug.Log($"Sending data packet of size: {data.Length} bytes");

                await stream.WriteAsync(data, 0, data.Length);
                Debug.Log("Data sent to server.");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"Error sending data: " + e.Message);
        }
    }


    private void OnDestroy()
    {
        isConnected = false;
        if (stream != null)
            stream.Close();
        if (client != null)
            client.Close();
    }
}
